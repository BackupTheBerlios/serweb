<?php
/* File with stationnames in Saint Lucia */

$country = 'Saint Lucia';

$icaos   = array(
  'TLPL' => 'Hewanorra International Airport',
  'TLPC' => 'Vigie'
);

?>
