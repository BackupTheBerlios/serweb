<?php
/* File with stationnames in Mozambique */

$country = 'Mozambique';

$icaos   = array(
  'FQBR' => 'Beira',
  'FQCH' => 'Chimoio',
  'FQCB' => 'Cuamba',
  'FQIN' => 'Inhambane',
  'FQLC' => 'Lichinga',
  'FQLU' => 'Lumbo',
  'FQMA' => 'Maputo / Mavalane',
  'FQMP' => 'Mocimboa Da Praia',
  'FQNP' => 'Nampula',
  'FQPB' => 'Pemba',
  'FQQL' => 'Quelimane',
  'FQTE' => 'Tete',
  'FQVL' => 'Vilanculos',
  'FQXA' => 'Xai Xai'
);

?>
