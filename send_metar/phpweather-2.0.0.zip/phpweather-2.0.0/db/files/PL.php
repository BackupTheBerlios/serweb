<?php
/* File with stationnames in Poland */

$country = 'Poland';

$icaos   = array(
  'EPGD' => 'Gdansk-Rebiechowo',
  'EPKT' => 'Katowice',
  'EPKO' => 'Koszalin',
  'EPKK' => 'Krakow',
  'EPPO' => 'Poznan',
  'EPRZ' => 'Rzeszow-Jasionka',
  'EPSC' => 'Szczecin',
  'EPWA' => 'Warszawa-Okecie',
  'EPWR' => 'Wroclaw Ii',
  'EPZG' => 'Zielona Gora'
);

?>
