<?php
/* File with stationnames in Myanmar */

$country = 'Myanmar';

$icaos   = array(
  'VBBM' => 'Bhamo',
  'VBCI' => 'Coco Island',
  'VBTV' => 'Dawei',
  'VBHL' => 'Homalin',
  'VBPA' => 'Hpa-An',
  'VBKG' => 'Kengtung',
  'VBKP' => 'Kyaukpyu',
  'VBLS' => 'Lashio',
  'VBRM' => 'Mandalay',
  'VBML' => 'Meiktila',
  'VBRN' => 'Mergui',
  'VBRR' => 'Mingaladon',
  'VBMM' => 'Moulmein',
  'VBMK' => 'Myitkyina',
  'VBBS' => 'Pathein',
  'VBPR' => 'Prome',
  'VBPT' => 'Putao',
  'VBSY' => 'Sandoway',
  'VYSW' => 'Sittwe',
  'VYYY' => 'Yangon'
);

?>
