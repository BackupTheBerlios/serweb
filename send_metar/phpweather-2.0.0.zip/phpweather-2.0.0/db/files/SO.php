<?php
/* File with stationnames in Somalia */

$country = 'Somalia';

$icaos   = array(
  'HCMN' => 'Belet Uen',
  'HCMI' => 'Berbera',
  'HCMV' => 'Burao',
  'HCMH' => 'Hargeisa',
  'HCMM' => 'Mogadiscio'
);

?>
