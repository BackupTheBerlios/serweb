<?php
/* File with stationnames in Tonga */

$country = 'Tonga';

$icaos   = array(
  'NFTF' => 'Fua\'Amotu',
  'NFTL' => 'Haapai'
);

?>
