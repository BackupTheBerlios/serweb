<?php
/* File with stationnames in Christmas Island */

$country = 'Christmas Island';

$icaos   = array(
  'YPXM' => 'Christmas Island Aerodrome',
  'YPCC' => 'Cocos Island Airport'
);

?>
