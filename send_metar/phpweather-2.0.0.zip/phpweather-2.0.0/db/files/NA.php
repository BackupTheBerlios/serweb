<?php
/* File with stationnames in Namibia */

$country = 'Namibia';

$icaos   = array(
  'FAGB' => 'Gobabis',
  'FYGF' => 'Grootfontein',
  'FYWH' => 'J. G. Strijdom',
  'FYKT' => 'Keetmanshoop',
  'FYRU' => 'Rundu'
);

?>
