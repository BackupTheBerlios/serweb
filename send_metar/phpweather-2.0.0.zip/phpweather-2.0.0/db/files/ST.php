<?php
/* File with stationnames in Sao Tome and Principe */

$country = 'Sao Tome and Principe';

$icaos   = array(
  'FPPR' => 'Principe',
  'FPST' => 'Sao Tome'
);

?>
