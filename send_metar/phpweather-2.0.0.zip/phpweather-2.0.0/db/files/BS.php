<?php
/* File with stationnames in Bahamas */

$country = 'Bahamas';

$icaos   = array(
  'MYBS' => 'Alice Town, Bimini',
  'MYSM' => 'Cockburn Town, San Salvador',
  'MYGF' => 'Freeport, Grand Bahama',
  'MYEG' => 'Georgetown, Exuma',
  'MYIG' => 'Matthew Town, Inagua',
  'MYNN' => 'Nassau Airport',
  'MYGW' => 'West End, Grand Bahama'
);

?>
