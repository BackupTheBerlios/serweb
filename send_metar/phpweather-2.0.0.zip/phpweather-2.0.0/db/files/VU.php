<?php
/* File with stationnames in Vanuatu */

$country = 'Vanuatu';

$icaos   = array(
  'NVVV' => 'Bauerfield Efate',
  'NVSL' => 'Lamap Malekula',
  'NVSS' => 'Pekoa Airport Santo',
  'NVSC' => 'Sola Vanua Lava'
);

?>
