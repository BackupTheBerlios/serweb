<?php
/* File with stationnames in Ukraine */

$country = 'Ukraine';

$icaos   = array(
  'UKBB' => 'Boryspil',
  'UKHH' => 'Kharkiv',
  'UKKK' => 'Kyiv',
  'UKLL' => 'L\'Viv',
  'UKOO' => 'Odesa',
  'UKFF' => 'Simferopol'
);

?>
