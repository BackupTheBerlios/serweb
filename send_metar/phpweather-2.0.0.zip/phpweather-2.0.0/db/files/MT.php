<?php
/* File with stationnames in Malta */

$country = 'Malta';

$icaos   = array(
  'LMML' => 'Luqa'
);

?>
