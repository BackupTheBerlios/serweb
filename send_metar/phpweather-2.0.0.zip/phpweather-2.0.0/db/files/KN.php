<?php
/* File with stationnames in Saint Kitts and Nevis */

$country = 'Saint Kitts and Nevis';

$icaos   = array(
  'TKPK' => 'Golden Rock'
);

?>
