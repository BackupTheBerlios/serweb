<?php
/* File with stationnames in Antigua and Barbuda */

$country = 'Antigua and Barbuda';

$icaos   = array(
  'TKPN' => 'Charlestown / Newcast',
  'TAPA' => 'Vc Bird International Airport Antigua'
);

?>
