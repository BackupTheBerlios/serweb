<?php
/* File with stationnames in Egypt */

$country = 'Egypt';

$icaos   = array(
  'HEAX' => 'Alexandria / Nouzha',
  'HESN' => 'Asswan',
  'HEAT' => 'Asyut',
  'HECA' => 'Cairo Airport',
  'HEAR' => 'El Arish',
  'HETR' => 'El Tor',
  'HEGN' => 'Hurguada',
  'HELX' => 'Luxor',
  'HEMM' => 'Mersa Matruh',
  'HEPS' => 'Port Said',
  'HESH' => 'Sharm El Sheikhintl'
);

?>
