<?php
/* File with stationnames in Western Sahara */

$country = 'Western Sahara';

$icaos   = array(
  'GSVO' => 'Villa Cisneros'
);

?>
