<?php
/* File with stationnames in Portugal */

$country = 'Portugal';

$icaos   = array(
  'LPBJ' => 'Beja',
  'LPBG' => 'Braganca',
  'LPFR' => 'Faro / Aeroporto',
  'LPFL' => 'Flores Acores',
  'LPFU' => 'Funchal / S. Catarina',
  'LPHR' => 'Horta / Castelo Branco Acores',
  'LPLA' => 'Lajes Acores',
  'LPPT' => 'Lisboa / Portela',
  'LPPD' => 'Ponta Delgada / Nordela Acores',
  'LPPR' => 'Porto / Pedras Rubras',
  'LPPS' => 'Porto Santo',
  'LPAZ' => 'Santa Maria Acores',
  'LPVR' => 'Vila Real'
);

?>
