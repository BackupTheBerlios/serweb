<?php
/* File with stationnames in Equatorial Guinea */

$country = 'Equatorial Guinea';

$icaos   = array(
  'FGSL' => 'Malabo/Fernando Poo'
);

?>
