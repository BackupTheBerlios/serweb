<?php
/* File with stationnames in Yugoslavia */

$country = 'Yugoslavia';

$icaos   = array(
  'LQBK' => 'Banja Luka',
  'LYBE' => 'Beograd / Surcin',
  'LQBI' => 'Bihac',
  'LQMO' => 'Mostar',
  'LYNI' => 'Nis',
  'LYTI' => 'Podgorica / Golubovci',
  'LYPG' => 'Podgorica Titograd',
  'LYPR' => 'Pristina',
  'LQSA' => 'Sarajevo / Butmir',
  'LYTV' => 'Tivat',
  'LQTZ' => 'Tuzla',
  'LYVR' => 'Vrsac'
);

?>
