<?php
/* File with stationnames in Algeria */

$country = 'Algeria';

$icaos   = array(
  'DAUA' => 'Adrar',
  'DABB' => 'Annaba',
  'DABT' => 'Batna',
  'DAOR' => 'Bechar',
  'DAAE' => 'Bejaia',
  'DAUB' => 'Biskra',
  'DAAD' => 'Bou-Saada',
  'DAOI' => 'Chlef',
  'DABC' => 'Constantine',
  'DAAG' => 'Dar-El-Beida',
  'DAAJ' => 'Djanet',
  'DAFI' => 'Djelfa',
  'DAUE' => 'El Golea',
  'DAUO' => 'El Oued',
  'DAUG' => 'Ghardaia',
  'DAUH' => 'Hassi-Messaoud',
  'DAAP' => 'Illizi',
  'DAUZ' => 'In Amenas',
  'DAAV' => 'Jijel Achouat',
  'DAUL' => 'Laghouat',
  'DAAY' => 'Mecheria',
  'DAOO' => 'Oran / Es Senia',
  'DAUU' => 'Ouargla',
  'DAAS' => 'Setif',
  'DABP' => 'Skikda',
  'DAAT' => 'Tamanrasset / Aguenna',
  'DABS' => 'Tebessa',
  'DAOB' => 'Tiaret',
  'DAUT' => 'Timimoun',
  'DAOF' => 'Tindouf',
  'DAON' => 'Tlemcen Zenata',
  'DAUK' => 'Touggourt'
);

?>
