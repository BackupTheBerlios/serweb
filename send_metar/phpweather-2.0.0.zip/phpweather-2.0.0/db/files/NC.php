<?php
/* File with stationnames in New Caledonia */

$country = 'New Caledonia';

$icaos   = array(
  'NWWK' => 'Koumac Nlle-Caledonie',
  'NWWR' => 'La Roche Ile Mare',
  'NWWW' => 'La Tontouta Nlle-Caledonie',
  'NWWE' => 'Moue Ile Des Pins',
  'NWWN' => 'Noumea Nlle-Caledonie',
  'NWWL' => 'Ouanaham Ile Lifou',
  'NWWV' => 'Ouloup Ile Ouvea'
);

?>
