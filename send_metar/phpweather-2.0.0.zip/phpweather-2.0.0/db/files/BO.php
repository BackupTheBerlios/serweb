<?php
/* File with stationnames in Bolivia */

$country = 'Bolivia';

$icaos   = array(
  'SLAP' => 'Apolo',
  'SLAS' => 'Ascencion De Guarayos',
  'SLCA' => 'Camiri',
  'SLCN' => 'Charana',
  'SLCO' => 'Cobija',
  'SLCB' => 'Cochabamba',
  'SLCP' => 'Concepcion',
  'SLGY' => 'Guayaramerin',
  'SLLP' => 'La Paz / Alto',
  'SLMG' => 'Magdalena',
  'SLOR' => 'Oruro',
  'SLPO' => 'Potosi',
  'SLPS' => 'Puerto Suarez',
  'SLRY' => 'Reyes',
  'SLRI' => 'Riberalta',
  'SLRB' => 'Robore',
  'SLRQ' => 'Rurrenabaque',
  'SLSB' => 'San Borja',
  'SLSM' => 'San Ignacio De Moxos',
  'SLSI' => 'San Ignacio De Velasco',
  'SLJV' => 'San Javier',
  'SLJO' => 'San Joaquin',
  'SLJE' => 'San Jose De Chiquitos',
  'SLSA' => 'Santa Ana',
  'SLET' => 'Santa Cruz / El Trompillo',
  'SLSU' => 'Sucre',
  'SLTJ' => 'Tarija',
  'SLTR' => 'Trinidad',
  'SLVM' => 'Villamontes',
  'SLVR' => 'Viru-Viru',
  'SLYA' => 'Yacuiba'
);

?>
