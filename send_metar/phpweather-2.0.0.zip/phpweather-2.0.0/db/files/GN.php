<?php
/* File with stationnames in Guinea */

$country = 'Guinea';

$icaos   = array(
  'GUOK' => 'Boke',
  'GUCY' => 'Conakry / Gbessia',
  'GUFH' => 'Faranah / Badala',
  'GUXD' => 'Kankan',
  'GUID' => 'Kindia',
  'GUKU' => 'Kissidougou',
  'GULB' => 'Labe',
  'GUMA' => 'Macenta',
  'GUNZ' => 'N\'Zerekore',
  'GUSI' => 'Siguiri'
);

?>
