<?php
/* File with stationnames in Swaziland */

$country = 'Swaziland';

$icaos   = array(
  'FDMS' => 'Manzini / Matsapa Airport'
);

?>
