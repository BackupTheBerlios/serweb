<?php
/* File with stationnames in Afghanistan */

$country = 'Afghanistan';

$icaos   = array(
  'OAFZ' => 'Faizabad',
  'OAFR' => 'Farah',
  'OAHR' => 'Herat',
  'OAJS' => 'Jabul-Saraj',
  'OAJL' => 'Jalalabad',
  'OAMS' => 'Mazar-I-Sharif',
  'OASG' => 'Shebirghan',
  'OASD' => 'Shindand',
  'OAZG' => 'Zaranj',
  'OAZB' => 'Zebak'
);

?>
