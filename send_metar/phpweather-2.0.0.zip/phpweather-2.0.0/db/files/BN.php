<?php
/* File with stationnames in Brunei Darussalam */

$country = 'Brunei Darussalam';

$icaos   = array(
  'WBSB' => 'Brunei Airport'
);

?>
