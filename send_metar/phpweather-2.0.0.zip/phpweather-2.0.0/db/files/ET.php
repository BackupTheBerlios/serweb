<?php
/* File with stationnames in Ethiopia */

$country = 'Ethiopia';

$icaos   = array(
  'HAAB' => 'Addis Ababa',
  'HAAM' => 'Arba Minch',
  'HHAS' => 'Asmara',
  'HASB' => 'Assab',
  'HALA' => 'Awassa',
  'HABD' => 'Bahar Dar',
  'HADC' => 'Combolcha',
  'HADM' => 'Debremarcos',
  'HADR' => 'Dire Dawa',
  'HAGO' => 'Gode',
  'HAGN' => 'Gondar',
  'HAGR' => 'Gore',
  'HAHM' => 'Harar Meda',
  'HAJJ' => 'Jiggiga',
  'HAJM' => 'Jimma',
  'HAMK' => 'Makale',
  'HAMS' => 'Massawa',
  'HANG' => 'Neghelli'
);

?>
