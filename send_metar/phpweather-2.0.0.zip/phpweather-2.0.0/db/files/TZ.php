<?php
/* File with stationnames in Tanzania, United Republic of */

$country = 'Tanzania, United Republic of';

$icaos   = array(
  'HTAR' => 'Arusha',
  'HTBU' => 'Bukoba',
  'HTDA' => 'Dar Es Salaam Airport',
  'HTDO' => 'Dodoma',
  'HTIR' => 'Iringa',
  'HTKA' => 'Kigoma',
  'HTKJ' => 'Kilimanjaro Airport',
  'HTMB' => 'Mbeya',
  'HTMO' => 'Mombo',
  'HTMG' => 'Morogoro',
  'HTMS' => 'Moshi',
  'HTMT' => 'Mtwara',
  'HTMU' => 'Musoma',
  'HTMW' => 'Mwanza',
  'HTNA' => 'Nachingwea',
  'HTPE' => 'Pemba / Karume Airport',
  'HTSE' => 'Same',
  'HTSY' => 'Shinyanga',
  'HTSO' => 'Songea',
  'HTTB' => 'Tabora Airport',
  'HTTG' => 'Tanga',
  'HTZA' => 'Zanzibar / Kisauni'
);

?>
