<?php
/* File with stationnames in Morocco */

$country = 'Morocco';

$icaos   = array(
  'GMAA' => 'Agadir',
  'GMAD' => 'Agadir Al Massira',
  'GMTA' => 'Al Hoceima',
  'GMMC' => 'Casablanca',
  'GMFK' => 'Errachidia',
  'GMMI' => 'Essaouira',
  'GMFF' => 'Fes-Sais',
  'GMFI' => 'Ifrane',
  'GMMY' => 'Kenitra',
  'GMMX' => 'Marrakech',
  'GMFM' => 'Meknes',
  'GMFN' => 'Nador',
  'GMMN' => 'Nouasseur',
  'GMMZ' => 'Ouarzazate',
  'GMFO' => 'Oujda',
  'GMME' => 'Rabat-Sale',
  'GMMS' => 'Safi',
  'GMMF' => 'Sidi Ifni',
  'GMAT' => 'Tan-Tan',
  'GMTT' => 'Tanger Aerodrome',
  'GMFZ' => 'Taza',
  'GMTN' => 'Tetuan / Sania Ramel'
);

?>
