<?php
/* File with stationnames in Jamaica */

$country = 'Jamaica';

$icaos   = array(
  'MKJP' => 'Kingston / Norman Manley',
  'MKJS' => 'Montego Bay / Sangster'
);

?>
