<?php
/* File with stationnames in Bahrain */

$country = 'Bahrain';

$icaos   = array(
  'OBBI' => 'Bahrain International Airport'
);

?>
