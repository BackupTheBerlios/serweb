<?php
/* File with stationnames in Cuba */

$country = 'Cuba';

$icaos   = array(
  'MUHA' => 'Aeropuerto Jose Marti, Rancho-Boyeros, Habana',
  'MUBA' => 'Baracoa, Oriente',
  'MUBY' => 'Bayamo',
  'MUCM' => 'Camaguey Aeropuerto',
  'MUCL' => 'Cayo Largo Del Sur',
  'MUCF' => 'Cienfuegos, Las Villas',
  'MUGT' => 'Guantanamo, Oriente',
  'MUGM' => 'Guantanamo, Oriente',
  'MUHG' => 'Holguin Civ / Mil',
  'MUVT' => 'Las Tunas, Las Tunas',
  'MUMZ' => 'Manzanillo, Oriente',
  'MUMO' => 'Moa Military',
  'MUNG' => 'Nueva Gerona, Isla De Pinos',
  'MUPR' => 'Pinar Del Rio, Pinar Del Rio',
  'MUCU' => 'Santiago De Cuba, Oriente',
  'MUVR' => 'Varadero, Matanzas',
  'MUCA' => 'Venezuela, Ciego De Avila'
);

?>
