<?php
/* File with stationnames in Marshall Islands */

$country = 'Marshall Islands';

$icaos   = array(
  'PKWA' => 'Kwajalein / Bucholz',
  'PKMJ' => 'Majuro / Marshall Island'
);

?>
