<?php
/* File with stationnames in Croatia */

$country = 'Croatia';

$icaos   = array(
  'LDDU' => 'Dubrovnik / Cilipi',
  'LDSH' => 'Hvar',
  'LDPL' => 'Pula Aerodrome',
  'LDRI' => 'Rijeka / Omisalj',
  'LDOR' => 'Slavonski Brod',
  'LDSP' => 'Split / Resnik',
  'LDVA' => 'Varazdin',
  'LDZD' => 'Zadar / Zemunik',
  'LDDD' => 'Zagreb / Maksimir',
  'LDZA' => 'Zagreb / Pleso'
);

?>
