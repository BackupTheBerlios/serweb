<?php
/* File with stationnames in Saint Vincent and the Grenadines */

$country = 'Saint Vincent and the Grenadines';

$icaos   = array(
  'TVSV' => 'Arnos Vale'
);

?>
