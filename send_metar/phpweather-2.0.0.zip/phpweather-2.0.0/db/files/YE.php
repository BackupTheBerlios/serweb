<?php
/* File with stationnames in Yemen */

$country = 'Yemen';

$icaos   = array(
  'OYAA' => 'Aden',
  'OYZM' => 'Al-Hazm',
  'OYAT' => 'Ataq',
  'OYHD' => 'Hodeidah',
  'OYMB' => 'Marib',
  'OYMK' => 'Mokha',
  'OYMC' => 'Mokha',
  'OYAR' => 'Riyan',
  'OYSN' => 'Sana\'A',
  'OYSY' => 'Sayun',
  'OYSQ' => 'Socotra',
  'OYTZ' => 'Taiz'
);

?>
