<?php
/* File with stationnames in Nepal */

$country = 'Nepal';

$icaos   = array(
  'VNBW' => 'Bhairawa Airport',
  'VNVT' => 'Biratnagar Airport',
  'VNJL' => 'Jumla',
  'VNKT' => 'Kathmandu Airport',
  'VNPK' => 'Pokhara Airport',
  'VNSI' => 'Simra Airport',
  'VNSK' => 'Surkhet',
  'VNTJ' => 'Taplejung'
);

?>
