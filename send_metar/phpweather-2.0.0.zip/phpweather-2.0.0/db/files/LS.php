<?php
/* File with stationnames in Lesotho */

$country = 'Lesotho';

$icaos   = array(
  'FXMU' => 'Maseru-Mia'
);

?>
