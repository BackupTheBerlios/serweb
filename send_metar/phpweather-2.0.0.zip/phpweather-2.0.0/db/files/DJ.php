<?php
/* File with stationnames in Djibouti */

$country = 'Djibouti';

$icaos   = array(
  'HFFF' => 'Djibouti',
  'HDAM' => 'Djibouti \\ Ambouli'
);

?>
