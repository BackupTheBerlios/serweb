<?php
/* File with stationnames in El Salvador */

$country = 'El Salvador';

$icaos   = array(
  'MSAC' => 'Acajutla',
  'MSLP' => 'El Salvador Intl. Airport / Comalapa',
  'MSSM' => 'San Miguel / El Papalon',
  'MSSS' => 'San Salvador / Ilopango',
  'MSSA' => 'Santa Ana / El Palmar'
);

?>
