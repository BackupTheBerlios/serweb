<?php
/* File with stationnames in Albania */

$country = 'Albania';

$icaos   = array(
  'LATI' => 'Tirana'
);

?>
