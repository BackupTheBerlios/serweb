<?php
/* File with stationnames in Belgium */

$country = 'Belgium';

$icaos   = array(
  'EBAW' => 'Antwerpen / Deurne',
  'EBBE' => 'Beauvechain',
  'EBBX' => 'Bertrix Bel-Afb',
  'EBLG' => 'Bierset',
  'EBBT' => 'Brasschaat',
  'EBBR' => 'Bruxelles National',
  'EBCI' => 'Charleroi / Gosselies',
  'EBCV' => 'Chievres',
  'EBLB' => 'Elsenborn',
  'EBFS' => 'Florennes',
  'EBZW' => 'Genk',
  'EBGT' => 'Gent / Industrie-Zone',
  'EBTN' => 'Goetsenhoven',
  'EBBL' => 'Kleine Brogel',
  'EBFN' => 'Koksijde',
  'EBMB' => 'Melsbroek Bel-Afb',
  'EBMT' => 'Munte',
  'EBOS' => 'Oostende Airport',
  'EBDT' => 'Schaffen',
  'EBST' => 'Sint-Truiden',
  'EBSP' => 'Spa / La Sauveniere',
  'EBSU' => 'St-Hubert',
  'EBWE' => 'Weelde Military'
);

?>
