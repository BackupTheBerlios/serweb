<?php
/* File with stationnames in Nauru */

$country = 'Nauru';

$icaos   = array(
  'ANAU' => 'Nauru Airport'
);

?>
