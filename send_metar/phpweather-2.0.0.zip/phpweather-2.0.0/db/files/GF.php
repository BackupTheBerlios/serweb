<?php
/* File with stationnames in French Guiana */

$country = 'French Guiana';

$icaos   = array(
  'SOCA' => 'Cayenne / Rochambeau',
  'SOOM' => 'Saint-Laurent-Du-Maroni'
);

?>
