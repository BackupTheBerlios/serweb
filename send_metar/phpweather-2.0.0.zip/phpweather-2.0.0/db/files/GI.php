<?php
/* File with stationnames in Gibraltar */

$country = 'Gibraltar';

$icaos   = array(
  'LXGB' => 'Gibraltar'
);

?>
