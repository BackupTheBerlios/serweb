<?php
/* File with stationnames in Lithuania */

$country = 'Lithuania';

$icaos   = array(
  'EYVI' => 'Vilnius'
);

?>
