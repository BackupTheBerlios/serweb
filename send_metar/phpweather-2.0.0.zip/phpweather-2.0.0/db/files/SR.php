<?php
/* File with stationnames in Suriname */

$country = 'Suriname';

$icaos   = array(
  'SMJP' => 'Johan A. Pengel',
  'SMZY' => 'Zanderij'
);

?>
