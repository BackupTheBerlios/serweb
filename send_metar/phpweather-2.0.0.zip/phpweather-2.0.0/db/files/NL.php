<?php
/* File with stationnames in Netherlands */

$country = 'Netherlands';

$icaos   = array(
  'EHAM' => 'Amsterdam Airport Schiphol',
  'EHDB' => 'De Bilt',
  'EHKD' => 'De Kooy',
  'EHDL' => 'Deelen',
  'EHEH' => 'Eindhoven',
  'EHGR' => 'Gilze-Rijen',
  'EHGG' => 'Groningen Airport Eelde',
  'EHLW' => 'Leeuwarden',
  'EHBK' => 'Maastricht Airport Zuid Limburg',
  'EHRD' => 'Rotterdam Airport Zestienhoven',
  'EHSB' => 'Soesterberg',
  'EHTW' => 'Twenthe',
  'EHVB' => 'Valkenburg',
  'EHVL' => 'Vlieland',
  'EHVK' => 'Volkel',
  'EHWO' => 'Woensdrecht'
);

?>
