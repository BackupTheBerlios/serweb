<?php
/* File with stationnames in Falkland Islands (Malvinas) */

$country = 'Falkland Islands (Malvinas)';

$icaos   = array(
  'SFAL' => 'Stanley Airport'
);

?>
