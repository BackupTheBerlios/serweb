<?php
/* File with stationnames in Belize */

$country = 'Belize';

$icaos   = array(
  'MZBZ' => 'Belize / Phillip Goldston Intl. Airport'
);

?>
