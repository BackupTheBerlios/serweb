<?php
/* File with stationnames in United Arab Emirates */

$country = 'United Arab Emirates';

$icaos   = array(
  'OMAD' => 'Abu Dhabi Bateen Airport',
  'OMAA' => 'Abu Dhabi International Airport',
  'OMAL' => 'Al Ain International Airport',
  'OMDB' => 'Dubai International Airport',
  'OMFJ' => 'Fujairah',
  'OMRK' => 'Ras Al Khaimah International Airport',
  'OMSJ' => 'Sharjah International Airport'
);

?>
