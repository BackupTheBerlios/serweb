<?php
/* File with stationnames in Zimbabwe */

$country = 'Zimbabwe';

$icaos   = array(
  'FVBB' => 'Beitbridge',
  'FVBI' => 'Binga',
  'FVCZ' => 'Buffalo Range',
  'FVBU' => 'Bulawayo Airport',
  'FVCH' => 'Chipinge',
  'FVGO' => 'Gokwe',
  'FVTL' => 'Gweru',
  'FVHA' => 'Harare Kutsaga',
  'FVWN' => 'Hwange National Park',
  'FVKB' => 'Kariba',
  'FVKA' => 'Karoi',
  'FVMV' => 'Masvingo',
  'FVMT' => 'Mutoko',
  'FVRU' => 'Rusape',
  'FVFA' => 'Victoria Falls'
);

?>
