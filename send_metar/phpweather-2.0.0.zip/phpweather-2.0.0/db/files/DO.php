<?php
/* File with stationnames in Dominican Republic */

$country = 'Dominican Republic';

$icaos   = array(
  'MDBH' => 'Barahona',
  'MDHE' => 'Herrera',
  'MDLR' => 'La Romana International Airport',
  'MDSD' => 'Las Americas',
  'MDPP' => 'Puerto Plata International',
  'MDPC' => 'Punta Cana',
  'MDST' => 'Santiago'
);

?>
