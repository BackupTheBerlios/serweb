<?php
/* File with stationnames in Maldives */

$country = 'Maldives';

$icaos   = array(
  'VRGN' => 'Gan',
  'VRMM' => 'Male'
);

?>
