<?php
/* File with stationnames in Kenya */

$country = 'Kenya';

$icaos   = array(
  'HKEL' => 'Eldoret',
  'HKEM' => 'Embu',
  'HKGA' => 'Garissa',
  'HKKG' => 'Kakamega',
  'HKKR' => 'Kericho',
  'HKKS' => 'Kisii',
  'HKKI' => 'Kisumu',
  'HKKT' => 'Kitale',
  'HKLU' => 'Lamu',
  'HKLO' => 'Lodwar',
  'HKMU' => 'Makindu',
  'HKML' => 'Malindi',
  'HKMA' => 'Mandera',
  'HKMB' => 'Marsabit',
  'HKME' => 'Meru',
  'HKMO' => 'Mombasa',
  'HKMY' => 'Moyale',
  'HKNC' => 'Nairobi / Dagoretti',
  'HKJK' => 'Nairobi / Kenyatta Airport',
  'HKNW' => 'Nairobi / Wilson',
  'HKNA' => 'Nairobi ACC/FIC/RCC/MET/COM/',
  'HKNK' => 'Nakuru',
  'HKNO' => 'Narok',
  'HKNI' => 'Nyeri',
  'HKVO' => 'Voi',
  'HKWJ' => 'Wajir'
);

?>
