<?php

/**
 * An 'or' dependency.
 *
 * This dependency is a collection of several dependencies, but it
 * will be satisfied as long a just one of them is satisfied.
 *
 * @author   Martin Geisler <gimpster@gimpster.com>
 * @version  pw_dependency_or.php,v 1.2 2002/04/13 13:12:29 gimpster Exp
 * @package  PHP Weather Configurator
 */
class pw_dependency_or extends pw_dependency {

  /**
   * Constructs a new 'or' dependency.
   *
   * @param string $option The name of the option that must satisfy
   * one of the dependencies.
   *
   * @param array $dependencies This should be an array of strings. If
   * the value of $option equals just one of these strings, then the
   * dependency is satisfied.
   *
   */
  function pw_dependency_or($option, $dependencies) {
    $this->pw_dependency($option, $dependencies);
  }

  function check() {
    $value = $GLOBALS['options'][$this->option]->get_value();
    foreach ($this->dep as $d) {
      if ($value == $d) return true;
    }
    return false;
  }

}

?>