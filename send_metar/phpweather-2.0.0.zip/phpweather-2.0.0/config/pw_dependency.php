<?php

/**
 * This is the baseclass for all dependencies.
 *
 * @author   Martin Geisler <gimpster@gimpster.com>
 * @version  pw_dependency.php,v 1.2 2002/04/13 13:12:29 gimpster Exp
 * @package  PHP Weather Configurator
 * @abstract
 */
class pw_dependency {

  /**
   * The name of an option.
   *
   * @var  string  The name of the option that should be checked.
   */
  var $option;

  /**
   * The value that the option must have to satisfy this dependency.
   *
   * @var  string  The required value.
   */
  var $dep;
  
  /**
   * Constructs a new dependency.
   *
   * @param string $option The name of the option that must satisfy
   * the dependency.
   * @param string $dep The required value of the option.
   *
   */
  function pw_dependency($option, $dep) {
    $this->option = $option;
    $this->dep = $dep;
  }

  /**
   * Checks a dependency.
   *
   * @return boolean True if the dependency is satisfied, false
   * otherwise.
   */
  function check() {
    return ($GLOBALS['options'][$this->option]->get_value() == $this->dep);
  }
}
?>