<?php

/* Miscellaneous functions that can help you build an interactive site
 * with PHP Weather. */

function get_countries_select($weather, $old_cc) {
  $output = '<select name="cc">';
   
  $countries = $weather->db->get_countries();
  while (list($cc, $country) = each($countries)) {
    if ($cc == $old_cc) {
      $output .= "\n<option value=\"$cc\" selected=\"selected\">$country</option>";
    } else {
      $output .= "\n<option value=\"$cc\">$country</option>";
    }
  }      
  $output .= "\n</select>\n";
  return $output;
}


function get_stations_select($weather, $cc, $old_icao) {
  
  $country = '';
  $icaos = $weather->db->get_icaos($cc, $country);
  
  $output = '<select name="icao">';

  while (list($icao, $name) = each($icaos)) {
    if ($icao == $old_icao) {
      $output .= "\n<option value=\"$icao\" selected=\"selected\">$name</option>";
    } else {
      $output .= "\n<option value=\"$icao\">$name</option>";
    }
  }
  $output .= "\n</select>\n";

  return $output;
}


function get_languages_select($weather, $old_language) {

  $output = '<select name="language">';
  $languages = $weather->get_languages('text');

  while (list($lc, $language) = each($languages)) {
    if ($lc == $old_language) {
      $output .= "\n<option value=\"$lc\" selected=\"selected\">$language</option>";
    } else {
      $output .= "\n<option value=\"$lc\">$language</option>";
    }
  }
  $output .= "\n</select>\n";

  return $output;
}

?>
