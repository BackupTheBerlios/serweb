<?php

require_once(PHPWEATHER_BASE_DIR . '/output/pw_text.php');

/**
 * Provides all the strings needed by pw_text to produce Slovak
 * output.
 *
 * @author   Ondrej Jomb�k <nepto@pobox.sk>
 * @author   Radoslava Fed�kov� <mortischka@pobox.sk>
 * @link     http://www.nepto.sk/	Nepto.SK - homepage
 * @link     http://www.platon.sk/	Platon software development group
 * @version  pw_text_sk.php,v 1.2 2002/08/28 21:13:40 gimpster Exp
 */

/* ViM 6.0 indentation used */

class pw_text_sk extends pw_text
{
  /**
   * This constructor provides all the strings used.
   *
   * @param  array  This is just passed on to pw_text().
   */
  function pw_text_sk($weather, $input = array())
    {
      $this->strings['charset']                  = 'ISO-8859-2';
      $this->strings['no_data']                  = '�utujem, moment�lne nie s� dostupn� �iadne inform�cie pre %s%s%s.';
      $this->strings['list_sentences_and']       = ' a ';
      $this->strings['list_sentences_comma']     = ', ';
      $this->strings['list_sentences_final_and'] = ' a ';
      $this->strings['location']                 = 'Toto je meterologick� report pre %s%s%s.';
      $this->strings['minutes']                  = ' min�tami';
      $this->strings['time_format']              = 'Report bol zostaven� pred %s, o %s%s%s UTC.';
      $this->strings['time_minutes']             = 'a %s%s%s min�tami';
      $this->strings['time_one_hour']            = '%sjednou%s hodinou %s';
      $this->strings['time_several_hours']       = '%s%s%s hodinami %s';
      $this->strings['time_a_moment']            = 'pr�ve teraz';
      $this->strings['meters_per_second']        = ' metrov za sekundu';
      $this->strings['miles_per_hour']           = ' m�� za hodinu';
      $this->strings['meter']                    = ' metrov';
      $this->strings['meters']                   = ' metre';
      $this->strings['feet']                     = ' st�p';
      $this->strings['kilometers']               = ' kilometrov';
      $this->strings['miles']                    = ' m�l';
      $this->strings['and']                      = ' a ';
      $this->strings['plus']                     = ' plus ';
      $this->strings['with']                     = ' s ';
      $this->strings['wind_blowing']             = 'R�chlos� vetra bola ';
      $this->strings['wind_with_gusts']          = ' so siln�m z�vanom od ';
      $this->strings['wind_from']                = ' z ';
      $this->strings['wind_variable']            = ' z %sr�znych%s smerov';
      $this->strings['wind_varying']             = ', meniaca sa medzi smerom z %s%s%s (%s%s&deg;%s) a %s%s%s (%s%s&deg;%s)';
      $this->strings['wind_calm']                = 'Vietor bol %spokojn�%s';
      $this->strings['wind_dir'] =
        array('severu',
              'severu/severov�chodu',
              'severov�chodu',
              'v�chodu/severov�chodu',
              'v�chodu',
              'v�chodu/juhov�chodu',
              'juhov�chodu',
              'juhu/juhov�chodu',
              'juhu',
              'juhu/juhoz�padu',
              'juhoz�padu',
              'z�padu/juhoz�padu',
              'z�padu',
              'z�padu/severoz�padu',
              'severoz�padu',
              'severu/severoz�padu',
              'severu');
      $this->strings['wind_dir_short'] =
        array('S',
              'SSV',
              'SV',
              'VSV',
              'V',
              'VJV',
              'JV',
              'JJV',
              'J',
              'JJZ',
              'JZ',
              'ZJZ',
              'Z',
              'ZSZ',
              'SZ',
              'SSZ',
              'S');
      $this->strings['wind_dir_short_long'] =
        array('S'  => 'sever',
              'SV' => 'severov�chod',
              'V'  => 'v�chod',
              'JV' => 'juhov�chod',
              'J'  => 'juh',
              'JZ' => 'juhoz�pad',
              'Z'  => 'z�pad',
              'SZ' => 'severoz�pad');
      $this->strings['temperature']     = 'Teplota bola ';
      $this->strings['dew_point']       = ' s rosn�m bodom ';
      $this->strings['altimeter']       = 'Atmosf�rick� tlak bol ';
      $this->strings['hPa']             = ' hPa';
      $this->strings['inHg']            = ' inHg';
      $this->strings['rel_humidity']    = 'Relat�vna vlhkos� vzduchu bola ';
      $this->strings['feelslike']       = 'Teplota sa zdala by� ';
      $this->strings['cloud_group_beg'] = 'Na oblohe boli ';
      $this->strings['cloud_group_end'] = '.';
      $this->strings['cloud_clear']     = 'Obloha bola %sjasn�%s.';
      $this->strings['cloud_height']    = ' oblaky vo v��ke ';
      $this->strings['cloud_overcast']  = ' obloha bola %szamra�en�%s od v��ky ';
      $this->strings['cloud_vertical_visibility'] = '%svertik�lna vidite�nos�%s bola ';
      $this->strings['cloud_condition'] =
        array('SKC' => 'prieh�adn�',
              'CLR' => 'jasn�',
              'FEW' => 'niektor�', /*'nieko�ko',*/
              'SCT' => 'rozpt�len�',
              'BKN' => 'zatiahnut�',
              'OVC' => 'zamra�en�');
      $this->strings['cumulonimbus']     = ' cumulonimbus';
      $this->strings['towering_cumulus'] = ' t��iace sa nahromaden�';
      $this->strings['cavok']            = ' �iadne oblaky pod %s a ani �iadne in� nahromaden� oblaky';
      $this->strings['currently']        = 'Aktu�lnym po�as�m bolo ';
      $this->strings['weather']          = 
        array(/* Intensity */
              '-' => ' riedky ',
              ' ' => ' stredn� ',
              '+' => ' hust� ',
              /* Proximity */
              'VC' => ' v pri�ahl�ch oblastiach',
              /* Descriptor */
              'PR' => ' �iasto�n�',
              'BC' => ' are�ly',
              'MI' => ' plytk�',
              'DR' => ' slab� pr�denie vzduchu',
              'BL' => ' veterno',
              'SH' => ' preh�nky',
              'TS' => ' b�rka s bleskami',
              'FZ' => ' mrznutie',
              /* Precipitation */
              'DZ' => ' mrholenie s ve�k�mi kvapkami',
              'RA' => ' d��', /* ' da�divo', */
              'SN' => ' sne�enie',
              'SG' => ' zrnit� sne�enie',
              'IC' => ' �adov� kry�t�liky',
              'PL' => ' �adovec',
              'GR' => ' krupobytie',
              'GS' => ' slab� krupobytie',
              'UP' => ' nezn�me',
              /* Obscuration */
              'BR' => ' hmlov� opar nad vodami',
              'FG' => ' hmlisto',
              'FU' => ' dymno',
              'VA' => ' sope�n� popol',
              'DU' => ' popra�ok',
              'SA' => ' pieso�no', /* pieso�n� */
              'HZ' => ' opar nad pohor�m',
              'PY' => ' mrholenie s mal�mi kvap��kami',
              /* Other */
              'PO' => ' pieso�n� v�ry',
              'SQ' => ' prudk� z�van vetra',
              'FC' => ' prietr� mra�ien',
              'SS' => ' pra�n� prieso�n� b�rka');
      $this->strings['visibility'] = 'Celkov� vidite�nos� bola ';
      $this->strings['visibility_greater_than']  = 'v��ia ako ';
      $this->strings['visibility_less_than']     = 'men�ia ako ';
      $this->strings['visibility_to']            = ' do ';
      /* this is left untranslated, because I have no metar, that use
       * this text -- Nepto [14/07/2002] */
      $this->strings['runway_upward_tendency']   = ' with an %supward%s tendency';
      $this->strings['runway_downward_tendency'] = ' with a %sdownward%s tendency';
      $this->strings['runway_no_tendency']       = ' with %sno distinct%s tendency';
      $this->strings['runway_between']           = 'between ';
      $this->strings['runway_left']              = ' left';
      $this->strings['runway_central']           = ' central';
      $this->strings['runway_right']             = ' right';
      $this->strings['runway_visibility']        = 'Vidite�nos� bola ';
      $this->strings['runway_for_runway']        = ' for runway ';

      /* We run the parent constructor */
      $this->pw_text($weather, $input);
    }

  function print_pretty_wind($wind)
    {
      extract($wind);
    
      if (! empty($meters_per_second)) {
        switch ($meters_per_second) {
        case 1:
          $this->strings['meters_per_second'] = ' meter za sekundu';
          break;
        case 2:
        case 3:
        case 4:
          $this->strings['meters_per_second'] = ' metre za sekundu';
          break;
        default:
          if ($meters_per_second - floor($meters_per_second) > 0)
            $this->strings['meters_per_second'] = ' metra za sekundu';
          break;
        }
      }
      if (! empty($miles_per_hour)) {
        switch ($miles_per_hour) {
        case 1:
          $this->strings['miles_per_hour'] = ' m��a za hodinu';
          break;
        case 2:
        case 3:
        case 4:
          $this->strings['miles_per_hour'] = ' m�le za hodinu';
          break;
        }
      }
    
      /*
       * Z/ZO grammar handling
       * zo severu, z juhu, zo zapadu, z vychodu
       */
      if (isset($deg)) {
        if ($deg == 'VRB') {
        } else {
          $idx = intval(round($deg / 22.5));
          if ($idx <= 2 || $idx >= 11) {
            $this->strings['wind_from'] =
              str_replace(' z ', ' zo ', $this->strings['wind_from']);
          }
        }
      }
    
      if (isset($var_beg)) {
        $idx = intval(round($var_beg / 22.5));
        if ($idx <= 2 || $idx >= 11) {
          $this->strings['wind_varying'] =
            str_replace(' z ', ' zo ', $this->strings['wind_varying']);
        }
      }
    
      return parent::print_pretty_wind($wind);
    }

  function parse_cloud_group($cloud_group)
    {
      extract($cloud_group);
    
      if (isset($condition) && $condition == 'CAVOK') {
        $this->strings['cloud_group_beg'] =
          str_replace(' boli ', ' neboli ', $this->strings['cloud_group_beg']);
      }
    
      return parent::parse_cloud_group($cloud_group);
    }
  
  function print_pretty_time($time)
    {
      $minutes_old = round((time() - $time)/60);
      if ($minutes_old > 60) {
        $minutes = $minutes_old % 60;
        if ($minutes == 1) {
          $this->strings['time_minutes']  = 'a %s%s%s min�tou';
        }
      } else {
        if ($minutes_old < 5) {
          /* we must remove word 'pred', because we wanted string:
           * 'Report bol zostaven� prave teraz, ...' */
          $this->strings['time_format'] =
            str_replace(' pred ', ' ', $this->strings['time_format']);
        }
      }
    
      return parent::print_pretty_time($time);
    }
  
  function print_pretty_weather($weather)
    {
      if ($weather[0]['descriptor'] == 'SH') {
        $this->strings['currently'] = str_replace(' bolo ', ' boli ',
                                                  $this->strings['currently']);
        if ($weather[0]['precipitation'] == 'RA') {
          $this->strings['weather']['-']  = ' riedkeho ';
          $this->strings['weather'][' ']  = ' stredn�ho ';
          $this->strings['weather']['+']  = ' hust�ho ';
          $this->strings['weather']['RA'] = ' da��a';
        }
      } elseif ($weather[0]['precipitation'] == 'RA'
                || $weather[0]['obscuration'] == 'HZ') {
        $this->strings['currently'] = str_replace(' bolo ', ' bol ',
                                                  $this->strings['currently']);
      }

      return parent::print_pretty_weather($weather);
    }
}

/*

NOTES:
------

Metars to test:
+----+------+---------------------------------------------------------------------------------+
| cc | icao | metar                                                                           |
+----+------+---------------------------------------------------------------------------------+
| FI | EFKK | EFKK 281950Z 18008KT 150V220 9999 -SHRA FEW012 SCT016 BKN020 BKN075 12/12 Q0998 |
| KH | VDPP | VDPP 281030Z 23008KT 9000 FEW015 FEW025CB SCT300 33/26 Q1008 CB:S/NW/E          |
+----+------+---------------------------------------------------------------------------------+

Why is there backslash instead of slash in Airport name?
cc=DJ&icao=HDAM

Problematic metars:
201530Z VABB 24012KT 5000 FU FEW018 SCT025 28/22 Q1004 NOSIG
MWCR 2820000Z 12016KT 9999 HZ FEW016 BKN200 32/25 Q1015 NOSIG
CYZT 281900Z 10019G26KT 20SM VCSH FEW025 BKN050 OVC110 13/09 A2956 RMK SC1SC6AC2 SLP009


 */

?>
