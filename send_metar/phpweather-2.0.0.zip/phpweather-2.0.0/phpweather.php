<?php

/**
 * The base directory of the PHP Weather installation.
 *
 * When another file needs to include a file, this constant is used as
 * the base directory. The location of this file defines the base
 * directory
 *
 * @const PHPWEATHER_BASE_DIR The base directory. 
 */
define('PHPWEATHER_BASE_DIR', dirname(__FILE__));
/* Due to a strange bug in PHPDoc, you must quote dirname(__FILE__)
 * before you run PHPDoc! PHPDoc crashes with a segmentation fault on
 * my system if the value is unquoted... */

/**
 * Require the parent class.
 * @include The definition of data_retrieval.
 */
require_once(PHPWEATHER_BASE_DIR . '/data_retrieval.php');

/**
 * PHP Weather is a class that understands how to parse a raw METAR.
 *
 * The decoded METAR is saved in $decoded_metar, in a language-neutral
 * format.
 *
 * @author   Martin Geisler <gimpster@gimpster.com>
 * @version  phpweather.php,v 1.31 2002/08/26 13:15:23 gimpster Exp
 * @package  PHP Weather
 * @access   public
 * @see	     $decoded_metar
 */
class phpweather extends data_retrieval {
  
  /**
   * The decoded METAR is stored here.
   *
   * $decoded_metar is an array of arrays. Each sub-array corresponds
   * to a group of related weather-info. We have cloud-groups,
   * visibility-groups and so on.
   *
   * @var  array
   */
  var $decoded_metar;
  
  /**
   * This constructor does nothing besides passing the input down the
   * hierarchy.
   *
   * @param	array	The initial properties of the object.
   */
  function phpweather($input = array()) {
    /* This class doesn't have any defaults, so it just calls the
     * parent constructor.
     */
    $this->data_retrieval($input);
  }

  
  /**
   * Returns a list of languages.
   *
   * @return array   An associative array with the language codes as the
   * keys and the names of the languages as the values.
   *
   * @param  string  The type of output module you're interested in, eg.
   *                 'text' for the text output module.
   *
   * @access  public
   */
  function get_languages($type) {

    static $output = array();
    
    if (empty($output)) {

      require(PHPWEATHER_BASE_DIR . '/languages.php');
      $this->debug("Finding language for $type");
      
      $dir = opendir(PHPWEATHER_BASE_DIR . '/output');
      while($file = readdir($dir)) {
        if (ereg("^pw_${type}_([a-z][a-z])\.php$", $file, $regs)) {
          $output[$regs[1]] = $languages[$regs[1]];
        }
      }
      closedir($dir);
    }

    asort($output);

    return $output;
  }

 
  /**
   * Helper-function used to store temperatures.
   *
   * Given a numerical temperature $temp in Celsius, coded to tenth of
   * degree, store in $temp_c, convert to Fahrenheit and store in
   * $temp_f.
   *
   * @param string   Temperature to convert, coded to tenth of
   * 		     degree, like 1015
   * @param   integer   Temperature measured in degrees Celsius
   * @param   integer   Temperature measured in degrees Fahrenheit
   * @access  private
   */
  function store_temp($temp, &$temp_c, &$temp_f) {
    /*
     * Note: $temp is converted to negative if $temp > 100.0 (See
     * Federal Meteorological Handbook for groups T, 1, 2 and 4). 
     * For example, a temperature of 2.6�C and dew point of -1.5�C 
     * would be reported in the body of the report as "03/M01" and the
     * TsnT'T'T'snT'dT'dT'd group as "T00261015").  
     */
    
    if ($temp[0] == 1) {
      $temp[0] = '-';
    }
    $temp_c = number_format($temp,1);
    /* The temperature in Fahrenheit. */
    $temp_f = number_format($temp * (9/5) + 32, 1);
  }
  
  
  /**
   * Helper-function used to store speeds.
   *
   * $value is converted and stored based on $windunit.
   *
   * @param  float   The value one seeks to convert.
   * @param  string  The unit of $value.
   * @param  float &$knots   After $value has been converted into knots,
   *			     it will be stored in this variable.
   * @param  float &$meterspersec   After $value has been converted into
   *				    meters per second, it will be stored 
   *				    in this variable.
   * @param  float &$milesperhour   After $value has been converted into
   *				    miles per hour, it will be stored 
   *				    in this variable.
   * @access  private
   */
  function store_speed($value, $windunit, &$knots, &$meterspersec, &$milesperhour) {
    if ($value == 0) {
      $knots = 0;
      $meterspersec = 0;
      $milesperhour = 0;
      return;
    }
    
    if ($windunit == 'KT') {
      /* The windspeed measured in knots: */
      $knots        = number_format($value);
      /* The windspeed measured in meters per second, rounded to one
         decimal place  */
      $meterspersec = number_format($value * 0.5144, 1);
      /* The windspeed measured in miles per hour, rounded to one
         decimal place */
      $milesperhour = number_format($value * 1.1508, 1);
    } elseif ($windunit == 'MPS') {
      /* The windspeed measured in meters per second */
      $meterspersec = number_format($value);
      /* The windspeed measured in knots, rounded to one decimal
         place */
      $knots        = number_format($value / 0.5144, 1);
      /* The windspeed measured in miles per hour, rounded to one
         decimal place */
      $milesperhour = number_format($value / 0.5144 * 1.1508, 1);
    } elseif ($windunit == 'KMH') {
      /* The windspeed measured in kilometers per hour */
      $meterspersec = number_format($value * 1000 / 3600, 1);
      $knots        = number_format($value * 1000 / 3600 / 0.5144, 1);
      /* The windspeed measured in miles per hour, rounded to one
         decimal place */
      $milesperhour = number_format($knots * 1.1508, 1);
    }
  }
  
  
  /**
   * Decodes a raw METAR.
   *
   * This function loops over the various parts of the raw METAR, and
   * stores the different bits in $decoded_metar. It uses get_metar() to
   * retrieve the METAR, so it is not necessary to connect to the database
   * before you call this function.
   *
   * @return  array   The decoded METAR.
   * @see     $decoded_metar
   * @access  public
   */
  function decode_metar() {
    /* initialization */
    $temp_visibility_miles = '';
    
    $decoded_metar['remarks'] = '';
    
    $decoded_metar['metar'] = $this->get_metar();
    $decoded_metar['location'] = $this->get_location();
    
    $parts = explode(' ', $this->metar);
    $num_parts = count($parts);
    for ($i = 0; $i < $num_parts; $i++) {
      $part = $parts[$i];
      
      if (ereg('RMK|TEMPO|BECMG|INTER', $part)) {
        /* The rest of the METAR is either a remark or temporary
         * information. We skip the rest of the METAR. 
         */
	$decoded_metar['remarks'] .= ' ' . $part;
	break;
      } elseif ($part == 'METAR') {
        /*
         * Type of Report: METAR
         */
	$decoded_metar['type'] = 'METAR';
      } elseif ($part == 'SPECI') {
        /*
         * Type of Report: SPECI
         */
	$decoded_metar['type'] = 'SPECI';
      } elseif (ereg('^[A-Z]{4}$', $part) &&
                empty($decoded_metar['icao']))  {
        /*
         * Station Identifier
         */
	$decoded_metar['icao']  = $part;
      } elseif (ereg('([0-9]{2})([0-9]{2})([0-9]{2})Z', $part, $regs)) {
        /*
         * Date and Time of Report.
         *
         * We return a standard Unix UTC/GMT timestamp suitable for
         * gmdate().
         * Due to a bug in PHP, on some systems the time reported may
         * be incorrect. If you experience this, you can set 
         * $this->properties['offset'] to be the offset to add. For
         * example, if your times generated are 1 hour too early (so
         * metars appear an hour older than they are), set 
         * $this->properties['offset'] to be +1 in your defaults.php
         * file.
         */
	if ($regs[1] > gmdate('j')) {
          /* The day is greather that the current day of month => the
           * report is from last month. 
           */
	  $month = gmdate('n') - 1;
	} else {
	  $month = gmdate('n');
	}
	$decoded_metar['time'] =
          gmmktime($regs[2] + $this->properties['offset'],
                   $regs[3], 0, $month, $regs[1], gmdate('Y'));
      } elseif (ereg('(AUTO|COR|RTD|CC[A-Z]|RR[A-Z])', $part, $regs)) {
        
        /*
         * Report Modifier: AUTO, COR, CCx or RRx
         */
        $decoded_metar['report_mod'] = $regs[1];
      } elseif (ereg('([0-9]{3}|VRB)([0-9]{2,3})G?([0-9]{2,3})?(KT|MPS|KMH)', $part, $regs)) {
        
        /* Wind Group */
	
	$decoded_metar['wind']['deg'] = $regs[1];
	
	$this->store_speed($regs[2],
			   $regs[4],
			   $decoded_metar['wind']['knots'],
			   $decoded_metar['wind']['meters_per_second'],
			   $decoded_metar['wind']['miles_per_hour']);
	
	if (!empty($regs[3])) {
          
          /* We have a report with information about the gust.
           * First we have the gust measured in knots.
           */
	  $this->store_speed($regs[3],
			     $regs[4],
			     $decoded_metar['wind']['gust_knots'],
			     $decoded_metar['wind']['gust_meters_per_second'],
			     $decoded_metar['wind']['gust_miles_per_hour']);
	}
      } elseif (ereg('^([0-9]{3})V([0-9]{3})$', $part, $regs) &&
                !empty($decoded_metar['wind'])) {
        
        /*
         * Variable wind-direction
         */
        $decoded_metar['wind']['var_beg'] = $regs[1];
	$decoded_metar['wind']['var_end'] = $regs[2];
      } elseif (ereg('^([0-9]{4})([NS]?[EW]?)$', $part, $regs)) {
        /* 
         * Visibility in meters (4 digits only)
         */
        unset($group);

        if ($regs[1] == '0000') {
          /* Special low value */
          
	  $group['prefix'] = -1; /* Less than */
          $group['meter']  = 50;
          $group['km']     = 0.05;
          $group['ft']     = 164;
          $group['miles']  = 0.031;
	} elseif ($regs[1] == '9999') {
          /* Special high value */
          $group['prefix'] = 1; 
          $group['meter']  = 10000;
          $group['km']     = 10;
          $group['ft']     = 32800;
          $group['miles']  = 6.2;
	} else {
          /* Normal visibility, returned in both small and large units. */
          $group['prefix'] = 0; 
          $group['km']     = number_format($regs[1]/1000, 1);
          $group['miles']  = number_format($regs[1]/1609.344, 1);
          $group['meter']  = $regs[1] * 1;
          $group['ft']     = round($regs[1] * 3.28084);
	}
	if (!empty($regs[2])) {
	  $group['dir'] = $regs[2];
	}
        $decoded_metar['visibility'][] = $group;

      } elseif (ereg('^[0-9]$', $part)) {
        /*
         * Temp Visibility Group, single digit followed by space.
         */
        $temp_visibility_miles = $part;
      } elseif (ereg('^M?(([0-9]?)[ ]?([0-9])(/?)([0-9]*))SM$',
                     $temp_visibility_miles . ' ' . $part, $regs)) {
        /*
         * Visibility Group
         */
        unset($group);

	if ($regs[4] == '/') {
	  $vis_miles = $regs[2] + $regs[3]/$regs[5];
        } else {
          $vis_miles = $regs[1];
        }
        if ($regs[0][0] == 'M') {
          /* Prefix - less than */
          $group['prefix'] = -1;
        } else {
          $group['prefix'] = 0;
        }
        
        /* The visibility measured in miles */
        $group['miles']  = number_format($vis_miles, 1);
        
        /* The visibility measured in feet */
        $group['ft']     = round($vis_miles * 5280, 1);
        
        /* The visibility measured in kilometers */
        $group['km']     = number_format($vis_miles * 1.6093, 1);
        
        /* The visibility measured in meters */
        $group['meter']  = round($vis_miles * 1609.3);

        $decoded_metar['visibility'][] = $group;
      } elseif ($part == 'CAVOK') {
        /* CAVOK is used when the visibility is greater than 10
         * kilometers, the lowest cloud-base is at 5000 feet or more
         * and there is no significant weather.
         */
        unset($group);
        $group['prefix'] = 1; 
        $group['km']     = 10;
        $group['meter']  = 10000;
        $group['miles']  = 6.2;
        $group['ft']     = 32800;
        $decoded_metar['visibility'][] = $group;
        $decoded_metar['clouds'][]['condition'] = 'CAVOK';

      } elseif (ereg('^R([0-9]{2})([RLC]?)/([MP]?)([0-9]{4})' .
                     '([DNU]?)V?(P?)([0-9]{4})?([DNU]?)$', $part, $regs)) {
        /* Runway-group */
        unset($group);
        $group['nr'] = $regs[1];
	if (!empty($regs[2])) {
	  $group['approach'] = $regs[2];
	}
	
	if (!empty($regs[7])) {
          /* We have both min and max visibility since $regs[7] holds
           * the max visibility.
           */
          if (!empty($regs[5])) { 
            /* $regs[5] is tendency for min visibility. */
            $group['min_tendency'] = $regs[5];
	  }
	  
          if (!empty($regs[8])) { 
            /* $regs[8] is tendency for max visibility. */
            $group['max_tendency'] = $regs[8];
	  }
	  
	  if ($regs[3] == 'M') {
            /* Less than. */
            $group['min_prefix'] = -1;
	  }
          $group['min_meter'] = $regs[4] * 1;
          $group['min_ft']    = round($regs[4] * 3.2808);
	  
	  if ($regs[6] == 'P') {
            /* Greater than. */
            $group['max_prefix'] = 1;
	  }
          $group['max_meter'] = $regs[7] * 1;
          $group['max_ft']    = round($regs[7] * 3.2808);
	  
	} else {
          /* We only have a single visibility. */
          
          if (!empty($regs[5])) { 
            /* $regs[5] holds the tendency for visibility. */
            $group['tendency'] = $regs[5];
	  }
	  
	  if ($regs[3] == 'M') {
            /* Less than. */
            $group['prefix'] = -1;
	  } elseif ($regs[3] == 'P') {
            /* Greater than. */
            $group['prefix'] = 1;
	  }
          $group['meter'] = $regs[4] * 1;
          $group['ft']    = round($regs[4] * 3.2808);
	}
        $decoded_metar['runway'][] = $group;
        
      } elseif (ereg('^(VC)?' .                           /* Proximity */
		     '(-|\+)?' .                          /* Intensity */
		     '(MI|PR|BC|DR|BL|SH|TS|FZ)?' .       /* Descriptor */
		     '((DZ|RA|SN|SG|IC|PL|GR|GS|UP)+)?' . /* Precipitation */
		     '(BR|FG|FU|VA|DU|SA|HZ|PY)?' .       /* Obscuration */
		     '(PO|SQ|FC|SS)?$',                   /* Other */
		     $part, $regs)) {
        /*
         * Current weather-group.
         */
        $decoded_metar['weather'][] =
          array('proximity'     => $regs[1],
                'intensity'     => $regs[2],
                'descriptor'    => $regs[3],
                'precipitation' => $regs[4],
                'obscuration'   => $regs[6],
                'other'         => $regs[7]);
        
      } elseif ($part == 'SKC' || $part == 'CLR') {
        /* Cloud-group */
        $decoded_metar['clouds'][]['condition'] = $part;

      } elseif (ereg('^(VV|FEW|SCT|BKN|OVC)([0-9]{3}|///)' .
                     '(CB|TCU)?$', $part, $regs)) {
        /* We have found (another) a cloud-layer-group. */
        unset($group);

	$group['condition'] = $regs[1];
	if (!empty($regs[3])) {
	  $group['cumulus'] = $regs[3];
	}
	if ($regs[2] == '000') {
          /* '000' is a special height. */
          $group['ft']     = 100;
          $group['meter']  = 30;
          $group['prefix'] = -1; /* Less than */
	} elseif ($regs[2] == '///') {
          /* '///' means height nil */
          $group['ft']     = 'nil';
          $group['meter']  = 'nil';
	} else {
          $group['ft']     = $regs[2] *100;
          $group['meter']  = round($regs[2] * 30.48);
	}
        $decoded_metar['clouds'][] = $group;

      } elseif (ereg('^(M?[0-9]{2})/(M?[0-9]{2})?$', $part, $regs)) {
        /*
         * Temperature/Dew Point Group.
         */
        $decoded_metar['temperature']['temp_c'] =
          round(strtr($regs[1], 'M', '-'));
        $decoded_metar['temperature']['temp_f'] =
          round(strtr($regs[1], 'M', '-') * (9/5) + 32);
	if (!empty($regs[2])) {
          $decoded_metar['temperature']['dew_c'] =
            round(strtr($regs[2], 'M', '-'));
          $decoded_metar['temperature']['dew_f'] =
            round(strtr($regs[2], 'M', '-') * (9/5) + 32);
	}
      } elseif (ereg('A([0-9]{4})', $part, $regs)) {
        /*
         * Altimeter.
         * The pressure measured in inHg.
         */
        $decoded_metar['altimeter']['inhg'] =
          number_format($regs[1]/100, 2);
        
        /* The pressure measured in mmHg, hPa and atm */
        $decoded_metar['altimeter']['mmhg'] =
          number_format($regs[1] * 0.254, 1, '.', '');
        $decoded_metar['altimeter']['hpa']  =
          round($regs[1] * 0.33864);
	$decoded_metar['altimeter']['atm']  =
          number_format($regs[1] * 3.3421e-4, 3, '.', '');
      } elseif (ereg('Q([0-9]{4})', $part, $regs)) {
        /*
         * Altimeter.
         * The specification doesn't say anything about
         * the Qxxxx-form, but it's in the METARs.
         */
        
        /* The pressure measured in hPa */
        $decoded_metar['altimeter']['hpa']  = round($regs[1]);
        
        /* The pressure measured in mmHg, inHg and atm */
        $decoded_metar['altimeter']['mmhg'] =
          number_format($regs[1] * 0.75006, 1, '.', '');
        $decoded_metar['altimeter']['inhg'] =
          number_format($regs[1] * 0.02953, 2);
        $decoded_metar['altimeter']['atm']  =
          number_format($regs[1] * 9.8692e-4, 3, '.', '');
      } elseif (ereg('^T([0-9]{4})([0-9]{4})', $part, $regs)) {
        
        /*
         * Temperature/Dew Point Group, coded to tenth of degree Celsius.
         */
	$this->store_temp($regs[1] / 10,
			  $decoded_metar['temperature']['temp_c'],
			  $decoded_metar['temperature']['temp_f']);
	$this->store_temp($regs[2] / 10,
			  $decoded_metar['temperature']['dew_c'],
			  $decoded_metar['temperature']['dew_f']);
      } elseif (ereg('^T([0-9]{4}$)', $part, $regs)) {
	$this->store_temp($regs[1],
			  $decoded_metar['temperature']['temp_c'],
			  $decoded_metar['temperature']['temp_f']);
      } elseif (ereg('^1([0-9]{4}$)', $part, $regs)) {
        
        /*
         * 6 hour maximum temperature Celsius, coded to tenth of degree
         */
	$this->store_temp($regs[1] / 10,
			  $decoded_metar['temp_min_max']['max6h_c'],
			  $decoded_metar['temp_min_max']['max6h_f']);
      } elseif (ereg('^2([0-9]{4}$)', $part, $regs)) {
        
        /*
         * 6 hour minimum temperature Celsius, coded to tenth of degree
         */
	$this->store_temp($regs[1] / 10,
			  $decoded_metar['temp_min_max']['min6h_c'],
			  $decoded_metar['temp_min_max']['min6h_f']);
      } elseif (ereg('^4([0-9]{4})([0-9]{4})$', $part, $regs)) {
        
        /*
         * 24 hour maximum and minimum temperature Celsius, coded to
         * tenth of degree
         */
	$this->store_temp($regs[1] / 10,
			  $decoded_metar['temp_min_max']['max24h_c'],
			  $decoded_metar['temp_min_max']['max24h_f']);
	$this->store_temp($regs[2] / 10,
			  $decoded_metar['temp_min_max']['min24h_c'],
			  $decoded_metar['temp_min_max']['min24h_f']);
      } elseif (ereg('^P([0-9]{4})', $part, $regs)) {
        
        /*
         * Precipitation during last hour in hundredths of an inch
         */
	if ($regs[1] == '0000') {
	  $decoded_metar['precipitation']['in'] = -1;
	  $decoded_metar['precipitation']['mm'] = -1;
	} else {
          $decoded_metar['precipitation']['in'] =
            number_format($regs[1]/100, 2);
          $decoded_metar['precipitation']['mm'] =
            number_format($regs[1]*0.254, 2);
	}
      } elseif (ereg('^6([0-9]{4})', $part, $regs)) {
        
        /*
         * Precipitation during last 3 or 6 hours in hundredths of an
         * inch.
         */
	if ($regs[1] == '0000') {
	  $decoded_metar['precipitation']['in_6h'] = -1;
	  $decoded_metar['precipitation']['mm_6h'] = -1;
	} else {
          $decoded_metar['precipitation']['in_6h'] =
            number_format($regs[1]/100, 2);
          $decoded_metar['precipitation']['mm_6h'] =
            number_format($regs[1]*0.254, 2);
	}
      } elseif (ereg('^7([0-9]{4})', $part, $regs)) {
        
        /*
         * Precipitation during last 24 hours in hundredths of an inch.
         */
	if ($regs[1] == '0000') {
	  $decoded_metar['precipitation']['in_24h'] = -1;
	  $decoded_metar['precipitation']['mm_24h'] = -1;
	} else {
          $decoded_metar['precipitation']['in_24h'] =
            number_format($regs[1]/100, 2, '.', '');
          $decoded_metar['precipitation']['mm_24h'] =
            number_format($regs[1]*0.254, 2, '.', '');
	}
      } elseif (ereg('^4/([0-9]{3})', $part, $regs)) {
        
        /*
         * Snow depth in inches
         */
	if ($regs[1] == '0000') {
	  $decoded_metar['precipitation']['snow_in'] = -1;
	  $decoded_metar['precipitation']['snow_mm'] = -1;
	} else {
	  $decoded_metar['precipitation']['snow_in'] = $regs[1] * 1;
	  $decoded_metar['precipitation']['snow_mm'] = round($regs[1] * 25.4);
	}
      } else {
        
        /*
         * If we couldn't match the group, we assume that it was a
         * remark.
         */
	$decoded_metar['remarks'] .= ' ' . $part;
      }
    }
    
    /*
     * Relative humidity
     */
    if (!empty($decoded_metar['temperature']['temp_c']) &&
	!empty($decoded_metar['temperature']['dew_c'])) {

      $decoded_metar['rel_humidity'] =
        number_format(pow(10, (1779.75 * ($decoded_metar['temperature']['dew_c'] -
                                          $decoded_metar['temperature']['temp_c'])
                               / ((237.3 + $decoded_metar['temperature']['dew_c']) *
                                  (237.3 + $decoded_metar['temperature']['temp_c']))
                               + 2)), 1);
    } 
    
    
    /*
     *  Compute windchill if temp < 40f and windspeed > 3 mph
     */
    if (!empty($decoded_metar['temperature']['temp_f']) && 
        $decoded_metar['temperature']['temp_f'] <= 40 &&
        !empty($decoded_metar['wind']['miles_per_hour']) &&
        $decoded_metar['wind']['miles_per_hour'] > 3) {
      $decoded_metar['windchill']['windchill_f'] = 
        number_format(35.74 + 0.6215*$decoded_metar['temperature']['temp_f'] 
                      - 35.75*pow((float)$decoded_metar['wind']['miles_per_hour'], 0.16) 
                      + 0.4275*$decoded_metar['temperature']['temp_f'] * 
                      pow((float)$decoded_metar['wind']['miles_per_hour'], 0.16));
      $decoded_metar['windchill']['windchill_c'] = 
        number_format(13.112 + 0.6215*$decoded_metar['temperature']['temp_c']
                      - 13.37*pow(($decoded_metar['wind']['miles_per_hour']/1.609), 0.16)
                      + 0.3965*$decoded_metar['temperature']['temp_c'] *
                      pow(($decoded_metar['wind']['miles_per_hour']/1.609), 0.16));
    }
	
    /*
     * Compute heat index if temp > 70F
     */
    if (!empty($decoded_metar['temperature']['temp_f']) &&
        $decoded_metar['temperature']['temp_f'] > 70 &&
        !empty($decoded_metar['rel_humidity'])) {
      $decoded_metar['heatindex']['heatindex_f'] =
        number_format(-42.379
                      + 2.04901523 * $decoded_metar['temperature']['temp_f']
                      + 10.1433312 * $decoded_metar['rel_humidity']
                      - 0.22475541 * $decoded_metar['temperature']['temp_f']
                                   * $decoded_metar['rel_humidity']
                      - 0.00683783 * $decoded_metar['temperature']['temp_f']
                                   * $decoded_metar['temperature']['temp_f']
                      - 0.05481717 * $decoded_metar['rel_humidity']
                                   * $decoded_metar['rel_humidity']
                      + 0.00122874 * $decoded_metar['temperature']['temp_f']
                                   * $decoded_metar['temperature']['temp_f']
                                   * $decoded_metar['rel_humidity']
                      + 0.00085282 * $decoded_metar['temperature']['temp_f']
                                   * $decoded_metar['rel_humidity']
                                   * $decoded_metar['rel_humidity']
                      - 0.00000199 * $decoded_metar['temperature']['temp_f']
                                   * $decoded_metar['temperature']['temp_f']
                                   * $decoded_metar['rel_humidity']
                                   * $decoded_metar['rel_humidity']);
     $decoded_metar['heatindex']['heatindex_c'] =
       number_format(($decoded_metar['heatindex']['heatindex_f'] - 32) / 1.8);
    }

    /*
     * Compute the humidity index
     */
    if (!empty($decoded_metar['rel_humidity'])) {
      $e = (6.112 * pow(10, 7.5 * $decoded_metar['temperature']['temp_c']
                        / (237.7 + $decoded_metar['temperature']['temp_c']))
            * $decoded_metar['rel_humidity'] / 100) - 10;
      $decoded_metar['humidex']['humidex_c'] =
        number_format($decoded_metar['temperature']['temp_c'] + 5/9 * $e, 1);
      $decoded_metar['humidex']['humidex_f'] =
        number_format($decoded_metar['humidex']['humidex_c'] * 9/5 + 32, 1);
    }

    
    /* Finally we store our decoded METAR in $this->decoded_metar so
     * that other methods can use it.
     */
    $this->decoded_metar = $decoded_metar;
    return $decoded_metar;
  }
}

?>
